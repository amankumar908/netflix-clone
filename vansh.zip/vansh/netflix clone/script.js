const faqItems = document.querySelectorAll('.faq-item');

faqItems.forEach((item) => {
  const button = item.querySelector('.faq-question');

  button.addEventListener('click', () => {
    const isOpen = item.classList.contains('active');

    faqItems.forEach((faq) => {
      faq.classList.remove('active');
    });

    if (!isOpen) {
      item.classList.add('active');
    }
  });
});

const scrollButtons = document.querySelectorAll('.scroll-btn');

scrollButtons.forEach((button) => {
  button.addEventListener('click', () => {
    const row = button.closest('.show-row-wrap')?.querySelector('.movie-row');
    if (!row) return;

    const direction = button.classList.contains('left') ? -1 : 1;
    const cardWidth = row.querySelector('.movie-card')?.getBoundingClientRect().width ?? 180;
    const gap = 16;
    row.scrollBy({
      left: (cardWidth + gap) * direction * 2,
      behavior: 'smooth',
    });
  });
});

const signupForm = document.querySelector('.get-started');
const formMessage = document.querySelector('.form-message');

signupForm?.addEventListener('submit', (event) => {
  event.preventDefault();

  const emailInput = document.getElementById('email');
  const value = emailInput.value.trim();
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  if (!value || !emailPattern.test(value)) {
    formMessage.textContent = 'Please enter a valid email address.';
    formMessage.style.color = '#ffdd99';
    emailInput.focus();
    return;
  }

  formMessage.textContent = 'Thanks! Your Netflix account setup is ready.';
  formMessage.style.color = '#66f2a2';
  signupForm.reset();

  setTimeout(() => {
    window.location.href = 'browse.html';
  }, 700);
});

document.querySelectorAll('[data-next-page]').forEach((button) => {
  button.addEventListener('click', () => {
    const target = button.getAttribute('data-next-page');
    if (target) {
      window.location.href = target;
    }
  });
});

const navLinks = document.querySelectorAll('a[href]');
navLinks.forEach((link) => {
  const href = link.getAttribute('href');
  if (href && href !== '#') {
    link.addEventListener('click', () => {
      if (link.dataset.page) {
        window.location.href = link.dataset.page;
      }
    });
  }
});

const year = document.getElementById('year');
if (year) {
  year.textContent = new Date().getFullYear();
}
