const makePosterSvg = (title, subtitle, accent = '#e50914', bg = '#111111') => {
  const safeTitle = String(title)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');

  const safeSubtitle = String(subtitle)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');

  const svg = `
    <svg xmlns="http://www.w3.org/2000/svg" width="900" height="1300" viewBox="0 0 900 1300">
      <defs>
        <linearGradient id="bg" x1="0" x2="1" y1="0" y2="1">
          <stop offset="0%" stop-color="${bg}" />
          <stop offset="100%" stop-color="${accent}" />
        </linearGradient>
      </defs>
      <rect width="900" height="1300" fill="url(#bg)"/>
      <rect x="28" y="28" width="844" height="1244" rx="24" fill="rgba(0,0,0,0.14)" stroke="rgba(255,255,255,0.2)"/>
      <circle cx="720" cy="260" r="170" fill="rgba(255,255,255,0.06)"/>
      <circle cx="175" cy="980" r="200" fill="rgba(255,255,255,0.05)"/>
      <text x="50%" y="50%" text-anchor="middle" font-size="76" font-family="Arial, Helvetica, sans-serif" font-weight="700" fill="#f5f5f5">${safeTitle}</text>
      <text x="50%" y="58%" text-anchor="middle" font-size="28" font-family="Arial, Helvetica, sans-serif" letter-spacing="4" fill="#f7d5d8">${safeSubtitle}</text>
      <text x="50%" y="88%" text-anchor="middle" font-size="28" font-family="Arial, Helvetica, sans-serif" fill="#ffffff">NETFLIX</text>
    </svg>
  `;

  return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(svg)}`;
};

const movieData = {
  trending: [
    {
      id: 1,
      title: 'The Dark Knight',
      genre: 'Action / Crime',
      year: 2008,
      rating: 'PG-13',
      duration: '2h 32m',
      banner: makePosterSvg('The Dark Knight', 'Featured', '#a50011', '#12090d'),
      poster: makePosterSvg('The Dark Knight', 'Action', '#e50914', '#170d10'),
      description: 'Batman faces a rising criminal mastermind who challenges the city and pushes Gotham to the edge of chaos.'
    },
    {
      id: 2,
      title: 'Stranger Things',
      genre: 'Sci-Fi / Horror',
      year: 2024,
      rating: 'TV-14',
      duration: '1h 24m',
      banner: makePosterSvg('Stranger Things', 'Featured', '#7b61ff', '#15132d'),
      poster: makePosterSvg('Stranger Things', 'Sci-Fi', '#6f66ff', '#18192f'),
      description: 'When a mysterious event disrupts a quiet town, a group of friends uncovers a dangerous supernatural mystery.'
    },
    {
      id: 3,
      title: 'Money Heist',
      genre: 'Thriller / Crime',
      year: 2023,
      rating: 'TV-MA',
      duration: '1h 18m',
      banner: makePosterSvg('Money Heist', 'Featured', '#d90429', '#17080d'),
      poster: makePosterSvg('Money Heist', 'Crime', '#e50914', '#1e0d10'),
      description: 'A mastermind and his crew pull off thrilling heists while trying to outsmart the authorities in a tense game of strategy.'
    },
    {
      id: 4,
      title: 'Wednesday',
      genre: 'Mystery / Comedy',
      year: 2025,
      rating: 'TV-14',
      duration: '1h 30m',
      banner: makePosterSvg('Wednesday', 'Featured', '#7a3dff', '#130c1a'),
      poster: makePosterSvg('Wednesday', 'Mystery', '#8b5cf6', '#1a101d'),
      description: 'A witty and macabre student navigates a strange school while solving chilling mysteries with style and wit.'
    },
    {
      id: 5,
      title: 'The Queen’s Gambit',
      genre: 'Drama / Sports',
      year: 2022,
      rating: 'TV-MA',
      duration: '1h 43m',
      banner: makePosterSvg('The Queen’s Gambit', 'Featured', '#f4a261', '#22130c'),
      poster: makePosterSvg('The Queen’s Gambit', 'Drama', '#f59e0b', '#1a120b'),
      description: 'A gifted chess prodigy rises through the world of competition as she battles ambition, addiction, and personal demons.'
    }
  ],
  popular: [
    {
      id: 6,
      title: 'The Irishman',
      genre: 'Drama / Crime',
      year: 2019,
      rating: 'R',
      duration: '3h 29m',
      banner: makePosterSvg('The Irishman', 'Featured', '#7c2d12', '#120b09'),
      poster: makePosterSvg('The Irishman', 'Drama', '#a16207', '#1a120d'),
      description: 'A hitman recounts a life of secrets, loyalty, and violence as time slowly catches up with him.'
    },
    {
      id: 7,
      title: '12 Angry Men',
      genre: 'Drama',
      year: 1957,
      rating: 'NR',
      duration: '1h 36m',
      banner: makePosterSvg('12 Angry Men', 'Featured', '#6ee7b7', '#0d1b17'),
      poster: makePosterSvg('12 Angry Men', 'Drama', '#34d399', '#0f1713'),
      description: 'Twelve jurors debate the fate of a defendant, forcing each of them to confront their own biases and beliefs.'
    },
    {
      id: 8,
      title: 'The Martian',
      genre: 'Adventure / Sci-Fi',
      year: 2015,
      rating: 'PG-13',
      duration: '2h 24m',
      banner: makePosterSvg('The Martian', 'Featured', '#f97316', '#1b120d'),
      poster: makePosterSvg('The Martian', 'Sci-Fi', '#f97316', '#1d120d'),
      description: 'An astronaut stranded on Mars fights to survive while his team works to bring him home.'
    },
    {
      id: 9,
      title: 'The Prestige',
      genre: 'Drama / Mystery',
      year: 2006,
      rating: 'PG-13',
      duration: '2h 18m',
      banner: makePosterSvg('The Prestige', 'Featured', '#f43f5e', '#1a0e12'),
      poster: makePosterSvg('The Prestige', 'Mystery', '#ec4899', '#1c0d1d'),
      description: 'Two rival magicians push each other to the brink in a deadly competition built on obsession and trickery.'
    },
    {
      id: 10,
      title: 'Inception',
      genre: 'Sci-Fi / Action',
      year: 2010,
      rating: 'PG-13',
      duration: '2h 28m',
      banner: makePosterSvg('Inception', 'Featured', '#3b82f6', '#0d1422'),
      poster: makePosterSvg('Inception', 'Sci-Fi', '#2563eb', '#101827'),
      description: 'A skilled thief enters dreams to steal secrets, but a mission that could change the world pushes him into danger.'
    }
  ],
  topRated: [
    {
      id: 11,
      title: 'The Godfather',
      genre: 'Crime / Drama',
      year: 1972,
      rating: 'R',
      duration: '2h 55m',
      banner: makePosterSvg('The Godfather', 'Featured', '#d97706', '#1a0f0a'),
      poster: makePosterSvg('The Godfather', 'Crime', '#f59e0b', '#1d130a'),
      description: 'The aging patriarch of a crime family struggles to preserve his empire while his sons face dangerous choices.'
    },
    {
      id: 12,
      title: 'Pulp Fiction',
      genre: 'Crime / Drama',
      year: 1994,
      rating: 'R',
      duration: '2h 34m',
      banner: makePosterSvg('Pulp Fiction', 'Featured', '#ef4444', '#160d0d'),
      poster: makePosterSvg('Pulp Fiction', 'Crime', '#f87171', '#1c0e0e'),
      description: 'Interconnected stories of criminals, outlaws, and redemption collide in one iconic, stylish masterpiece.'
    },
    {
      id: 13,
      title: 'Parasite',
      genre: 'Thriller / Drama',
      year: 2019,
      rating: 'R',
      duration: '2h 12m',
      banner: makePosterSvg('Parasite', 'Featured', '#a78bfa', '#160f1c'),
      poster: makePosterSvg('Parasite', 'Thriller', '#8b5cf6', '#1a101d'),
      description: 'A poor family infiltrates a wealthy household, setting off a chain of bitter revelations and tension.'
    },
    {
      id: 14,
      title: 'Schindler’s List',
      genre: 'Drama / History',
      year: 1993,
      rating: 'R',
      duration: '3h 15m',
      banner: makePosterSvg('Schindler’s List', 'Featured', '#f59e0b', '#1a1206'),
      poster: makePosterSvg('Schindler’s List', 'History', '#fbbf24', '#1e1408'),
      description: 'A businessman risks everything to save Jewish lives during one of history’s darkest chapters.'
    },
    {
      id: 15,
      title: 'Spirited Away',
      genre: 'Animation / Fantasy',
      year: 2001,
      rating: 'PG',
      duration: '2h 5m',
      banner: makePosterSvg('Spirited Away', 'Featured', '#38bdf8', '#08161d'),
      poster: makePosterSvg('Spirited Away', 'Fantasy', '#22d3ee', '#071820'),
      description: 'A young girl enters a magical spirit world and embarks on a brave journey to rescue her parents.'
    }
  ],
  action: [
    {
      id: 16,
      title: 'Mission: Impossible',
      genre: 'Action / Spy',
      year: 2024,
      rating: 'PG-13',
      duration: '2h 27m',
      banner: makePosterSvg('Mission', 'Featured', '#ef4444', '#1a0b0b'),
      poster: makePosterSvg('Mission', 'Action', '#f87171', '#1d0b0c'),
      description: 'An elite agent is thrown into a high-stakes mission where the mission itself may be impossible.'
    },
    {
      id: 17,
      title: 'John Wick',
      genre: 'Action / Crime',
      year: 2023,
      rating: 'R',
      duration: '2h 11m',
      banner: makePosterSvg('John Wick', 'Featured', '#ef4444', '#160d0d'),
      poster: makePosterSvg('John Wick', 'Action', '#f87171', '#1c0909'),
      description: 'A retired assassin returns to a brutal world of revenge, precision, and relentless fighting skill.'
    },
    {
      id: 18,
      title: 'Mad Max: Fury Road',
      genre: 'Action / Adventure',
      year: 2015,
      rating: 'R',
      duration: '2h 0m',
      banner: makePosterSvg('Mad Max', 'Featured', '#f59e0b', '#1d1307'),
      poster: makePosterSvg('Mad Max', 'Action', '#fbbf24', '#1b1308'),
      description: 'A lone drifter runs a deadly chase through a wasteland while fighting for survival and freedom.'
    },
    {
      id: 19,
      title: 'Black Panther',
      genre: 'Action / Sci-Fi',
      year: 2018,
      rating: 'PG-13',
      duration: '2h 14m',
      banner: makePosterSvg('Black Panther', 'Featured', '#f97316', '#1d1208'),
      poster: makePosterSvg('Black Panther', 'Sci-Fi', '#fb923c', '#1a0f06'),
      description: 'A king with a hidden kingdom and a legendary suit must defend his people and his nation from danger.'
    },
    {
      id: 20,
      title: 'Extraction',
      genre: 'Action / Thriller',
      year: 2020,
      rating: 'R',
      duration: '1h 57m',
      banner: makePosterSvg('Extraction', 'Featured', '#9c4221', '#1a0d0a'),
      poster: makePosterSvg('Extraction', 'Action', '#c2410c', '#1c100a'),
      description: 'A soldier is hired to extract a drug lord’s son from a city controlled by ruthless enemies.'
    }
  ],
  comedy: [
    {
      id: 21,
      title: 'The Hangover',
      genre: 'Comedy / Adventure',
      year: 2009,
      rating: 'R',
      duration: '1h 40m',
      banner: makePosterSvg('The Hangover', 'Featured', '#facc15', '#1e1807'),
      poster: makePosterSvg('The Hangover', 'Comedy', '#fbbf24', '#1a1207'),
      description: 'A bachelor party goes unexpectedly wrong as the men try to retrace an unforgettable night.'
    },
    {
      id: 22,
      title: 'Superbad',
      genre: 'Comedy',
      year: 2007,
      rating: 'R',
      duration: '1h 53m',
      banner: makePosterSvg('Superbad', 'Featured', '#f97316', '#1d1008'),
      poster: makePosterSvg('Superbad', 'Comedy', '#fb923c', '#1d1008'),
      description: 'Two teens embark on a chaotic mission before graduation, mixing awkwardness, rebellion, and growing up.'
    },
    {
      id: 23,
      title: 'The Devil Wears Prada',
      genre: 'Comedy / Drama',
      year: 2006,
      rating: 'PG-13',
      duration: '1h 49m',
      banner: makePosterSvg('Prada', 'Featured', '#e11d48', '#160b12'),
      poster: makePosterSvg('Prada', 'Comedy', '#f43f5e', '#180d13'),
      description: 'A young journalist lands a dream job working for a ruthless fashion editor with high expectations.'
    },
    {
      id: 24,
      title: 'Mean Girls',
      genre: 'Comedy',
      year: 2004,
      rating: 'PG-13',
      duration: '1h 37m',
      banner: makePosterSvg('Mean Girls', 'Featured', '#f472b6', '#190f17'),
      poster: makePosterSvg('Mean Girls', 'Comedy', '#ec4899', '#1a0d19'),
      description: 'A teenager navigates the social hierarchy of high school while learning to stay true to herself.'
    },
    {
      id: 25,
      title: 'Bridesmaids',
      genre: 'Comedy',
      year: 2011,
      rating: 'R',
      duration: '1h 57m',
      banner: makePosterSvg('Bridesmaids', 'Featured', '#fb7185', '#1a0d11'),
      poster: makePosterSvg('Bridesmaids', 'Comedy', '#f43f5e', '#1b0d0f'),
      description: 'A bride’s best friend struggles to stay afloat in an unpredictable wedding season filled with laughter and chaos.'
    }
  ],
  originals: [
    {
      id: 26,
      title: 'The Crown',
      genre: 'Drama / History',
      year: 2024,
      rating: 'TV-MA',
      duration: '1h 18m',
      banner: makePosterSvg('The Crown', 'Featured', '#a78bfa', '#120d1e'),
      poster: makePosterSvg('The Crown', 'Original', '#8b5cf6', '#120d1d'),
      description: 'The monarchy faces difficult choices and public scrutiny as political and personal challenges reshape a nation.'
    },
    {
      id: 27,
      title: 'The Witcher',
      genre: 'Fantasy / Action',
      year: 2024,
      rating: 'TV-MA',
      duration: '1h 22m',
      banner: makePosterSvg('The Witcher', 'Featured', '#22c55e', '#081a0d'),
      poster: makePosterSvg('The Witcher', 'Fantasy', '#16a34a', '#0b1b0f'),
      description: 'A monster hunter navigates a deadly world filled with magic, betrayal, and dangerous moral choices.'
    },
    {
      id: 28,
      title: 'Lucifer',
      genre: 'Crime / Fantasy',
      year: 2023,
      rating: 'TV-14',
      duration: '1h 14m',
      banner: makePosterSvg('Lucifer', 'Featured', '#f59e0b', '#1a1208'),
      poster: makePosterSvg('Lucifer', 'Fantasy', '#fbbf24', '#1b120c'),
      description: 'A charming devil uses his unique talents to help solve crimes while enjoying life in Los Angeles.'
    },
    {
      id: 29,
      title: 'Dark',
      genre: 'Sci-Fi / Thriller',
      year: 2020,
      rating: 'TV-MA',
      duration: '1h 39m',
      banner: makePosterSvg('Dark', 'Featured', '#38bdf8', '#071822'),
      poster: makePosterSvg('Dark', 'Sci-Fi', '#0ea5e9', '#071822'),
      description: 'A missing child case spirals into a mystery of time, identity, and the consequences of the past.'
    },
    {
      id: 30,
      title: 'Elite',
      genre: 'Drama / Mystery',
      year: 2024,
      rating: 'TV-MA',
      duration: '1h 31m',
      banner: makePosterSvg('Elite', 'Featured', '#10b981', '#091911'),
      poster: makePosterSvg('Elite', 'Drama', '#34d399', '#0b1714'),
      description: 'A new generation of students at an elite school faces secrets, scandals, and life-changing consequences.'
    }
  ]
};

const sectionLabels = {
  trending: 'Trending Now',
  popular: 'Popular on Netflix',
  topRated: 'Top Rated',
  action: 'Action Movies',
  comedy: 'Comedy Movies',
  originals: 'Netflix Originals'
};

const allMovieSections = Object.keys(movieData);

const contentContainer = document.getElementById('content-sections');
const heroTitle = document.getElementById('hero-title');
const heroDescription = document.getElementById('hero-description');
const heroYear = document.getElementById('hero-year');
const heroRating = document.getElementById('hero-rating');
const heroDuration = document.getElementById('hero-duration');
const heroBackdrop = document.getElementById('hero-backdrop');
const searchInput = document.getElementById('movie-search');
const movieModal = document.getElementById('movie-modal');
const modalTitle = document.getElementById('modal-title');
const modalMeta = document.getElementById('modal-meta');
const modalDesc = document.getElementById('modal-desc');
const modalBanner = document.getElementById('modal-banner');

function getMovieById(movieId) {
  const allMovies = Object.values(movieData).flat();
  return allMovies.find((movie) => movie.id === Number(movieId));
}

function createMovieCard(movie) {
  return `
    <article class="movie-card" data-id="${movie.id}" data-search-text="${movie.title} ${movie.genre}" tabindex="0" aria-label="${movie.title}">
      <div class="poster" style="background-image: url('${movie.poster}')">
        <div class="card-overlay">
          <span class="card-title">${movie.title}</span>
          <div class="card-actions">
            <button class="card-play" data-id="${movie.id}" type="button">▶ Play</button>
            <button class="card-info" data-id="${movie.id}" type="button">More Info</button>
          </div>
        </div>
      </div>
    </article>
  `;
}

function renderRows() {
  contentContainer.innerHTML = '';

  allMovieSections.forEach((sectionKey) => {
    const movies = movieData[sectionKey];
    const section = document.createElement('section');
    section.className = 'movie-row-section';
    section.id = sectionKey;
    section.innerHTML = `
      <div class="row-header">
        <h2>${sectionLabels[sectionKey]}</h2>
      </div>
      <div class="movie-row">
        ${movies.map(createMovieCard).join('')}
      </div>
    `;
    contentContainer.appendChild(section);
  });

  bindCardEvents();
}

function bindCardEvents() {
  document.querySelectorAll('.card-play').forEach((button) => {
    button.addEventListener('click', (event) => {
      const movieId = event.currentTarget.dataset.id;
      const movie = getMovieById(movieId);
      if (movie) {
        setHeroMovie(movie);
        alert(`Now playing: ${movie.title}`);
      }
    });
  });

  document.querySelectorAll('.card-info').forEach((button) => {
    button.addEventListener('click', (event) => {
      const movieId = event.currentTarget.dataset.id;
      openMovieModal(movieId);
    });
  });
}

function setHeroMovie(movie) {
  heroTitle.textContent = movie.title;
  heroDescription.textContent = movie.description;
  heroYear.textContent = movie.year;
  heroRating.textContent = movie.rating;
  heroDuration.textContent = movie.duration;
  heroBackdrop.style.backgroundImage = `url('${movie.banner}')`;

  const heroPlayButton = document.querySelector('.play-btn');
  const heroInfoButton = document.querySelector('.info-btn');

  if (heroPlayButton) {
    heroPlayButton.dataset.id = movie.id;
  }

  if (heroInfoButton) {
    heroInfoButton.dataset.id = movie.id;
  }
}

function openMovieModal(movieId) {
  const movie = getMovieById(movieId);
  if (!movie) return;

  modalTitle.textContent = movie.title;
  modalMeta.innerHTML = `
    <span>${movie.genre}</span>
    <span>${movie.year}</span>
    <span>${movie.rating}</span>
    <span>${movie.duration}</span>
  `;
  modalDesc.textContent = movie.description;
  modalBanner.style.backgroundImage = `url('${movie.banner}')`;
  movieModal.classList.remove('hidden');
}

function closeMovieModal() {
  movieModal.classList.add('hidden');
}

function filterMovies() {
  const query = searchInput.value.trim().toLowerCase();
  const cards = document.querySelectorAll('.movie-card');
  let anyMatch = false;

  cards.forEach((card) => {
    const text = card.dataset.searchText.toLowerCase();
    const matches = !query || text.includes(query);
    card.hidden = !matches;
    if (matches) anyMatch = true;
  });

  document.querySelectorAll('.movie-row-section').forEach((section) => {
    const visibleCards = section.querySelectorAll('.movie-card:not([hidden])').length;
    section.style.display = query && visibleCards === 0 ? 'none' : 'block';
  });

  if (!query) {
    document.querySelectorAll('.movie-row-section').forEach((section) => {
      section.style.display = 'block';
    });
  }

  if (!anyMatch && query) {
    const resultsMessage = document.createElement('p');
    resultsMessage.className = 'search-empty';
    resultsMessage.textContent = 'No movies matched your search.';

    const existingMessage = document.querySelector('.search-empty');
    if (existingMessage) existingMessage.remove();

    document.querySelector('.rows').appendChild(resultsMessage);
  } else {
    const existingMessage = document.querySelector('.search-empty');
    if (existingMessage) existingMessage.remove();
  }
}

function initializeEventHandlers() {
  const heroPlayButton = document.querySelector('.play-btn');
  heroPlayButton.addEventListener('click', () => {
    const movieId = heroPlayButton.dataset.id;
    const movie = getMovieById(movieId);
    if (movie) {
      alert(`Now playing: ${movie.title}`);
    }
  });

  const heroInfoButton = document.querySelector('.info-btn');
  heroInfoButton.addEventListener('click', () => {
    const movieId = heroInfoButton.dataset.id;
    openMovieModal(movieId);
  });

  document.querySelector('.close-btn').addEventListener('click', closeMovieModal);
  movieModal.addEventListener('click', (event) => {
    if (event.target === movieModal) {
      closeMovieModal();
    }
  });

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && !movieModal.classList.contains('hidden')) {
      closeMovieModal();
    }
  });

  searchInput.addEventListener('input', filterMovies);

  document.querySelector('.search-btn').addEventListener('click', () => {
    searchInput.focus();
  });
}

function init() {
  renderRows();
  const defaultMovie = movieData.trending[0];
  setHeroMovie(defaultMovie);
  initializeEventHandlers();
}

init();
