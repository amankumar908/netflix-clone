const faqItems = document.querySelectorAll('.faq-item');
const languageButton = document.querySelector('.lang-btn');
const signInButton = document.querySelector('.signin-btn');
const signupForm = document.querySelector('.signup-form');

faqItems.forEach((item) => {
  item.querySelector('.faq-question').addEventListener('click', () => {
    const isOpen = item.classList.contains('active');

    faqItems.forEach((faq) => {
      faq.classList.remove('active');
    });

    if (!isOpen) {
      item.classList.add('active');
    }
  });
});

languageButton.addEventListener('click', () => {
  const currentLanguage = languageButton.textContent.trim();
  languageButton.textContent = currentLanguage === 'English' ? 'हिन्दी' : 'English';
  alert(`Language switched to ${languageButton.textContent}.`);
});

signInButton.addEventListener('click', () => {
  alert('Sign in is ready. Please use the email form to continue your Netflix setup.');
  document.querySelector('.signup-form input').focus();
});

signupForm.addEventListener('submit', (event) => {
  event.preventDefault();

  const input = signupForm.querySelector('input');
  if (!input.value.trim()) {
    input.focus();
    input.placeholder = 'Please enter a valid email address';
    return;
  }

  alert('Thanks! Your Netflix membership setup is ready to begin.');
  signupForm.reset();
  input.placeholder = 'Email address';
});
